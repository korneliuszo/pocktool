Pocket Tools for SHARP Pocket Computer, Version 2.01a, 05. Jan. 2018 
(add of the the Linux scripts, fix the makefile typo error)

Install
-------

1. Extract the package to a directory or to a mobile stick
   All EXE, CMD and BAT files used have to be put in one directory.

   If you need more scripts from Scripts.win, you must copy it
   into this main directory.

2. Newest version of FileToOpen.exe you can get with wfile.zip from: 
   http://www.horstmuc.de/win.htm and put it in this directory

3. Read the Pocket Tools manual!

4. Edit SHARPSET.BAT

   - Uncomment or add our SHARP PC type (without "PC-")
   - Change all variables to match your directories and editors

5. Create links to the cmd files on your desktop or elsewhere


Use Pocket Tools scripts
------------------------

A) Start a cmd-script directly to activate the file-open dialog

B) Drag a file (BAS, WAV and what have you) on the appropriate cmd-script

C) Start a cmd-script from terminal window with more parameters
   use first parameter ? to activate the file-open dialog

bas2wav.cmd	convert a SHARP BASIC text file to a wave file

wav2bas.cmd	convert a wave file to a editable BASIC text file

