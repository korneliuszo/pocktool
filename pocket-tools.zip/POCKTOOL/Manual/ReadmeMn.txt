A revised manual is in progress. Thanks to Norbert and Ira!
A German manual is planned.
